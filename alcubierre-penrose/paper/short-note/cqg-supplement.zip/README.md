# Supplementary material

Can the Journey Continue? The Boundaries of Alcubierre Spacetimes
by Sergei Slobodov.

The manuscript contains the proofs. This archive contains symbolic checks
of the horizon chart and the transverse curvature identities, and the
code and output for Figure 1.

From the extracted directory, run:

    python -m pip install -r requirements.txt
    python checks/extension_metric.py
    python checks/flat_cap_partial_extension.py
    python supplement/scripts/bubble_extension_comparison.py

The first check verifies the pullback and determinant in Appendix A.3.
The second also verifies the two curvature contractions in Appendix A.2
and writes a report under output/sech/. The figure script verifies the
shared axial metric, the wall sections, and the crossing before writing
figures/bubble_extension_comparison.pdf and .png. Figure1.pdf is the
figure included in the manuscript. The file meridional_geometry.py
provides the coordinate and geodesic calculations used by the figure
script.

Verified with Python 3.12, NumPy 2.5.1, SciPy 1.18.0, SymPy 1.14.0,
and Matplotlib 3.11.1.
